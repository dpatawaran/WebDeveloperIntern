var fruitsArray = [
  { name: 'Banana', image: 'images/banana.jpg' }, 
  { name: 'Apple', image: 'images/apple.jpg' }, 
  { name: 'Orange', image: 'images/orange.jpg' },
  { name: 'BlueBerries', image: 'images/blueberries.jpg' },
  { name: 'Grapes', image: 'images/grapes.jpg' }
];

//variable that will let user only turn 2 cards at a time
var cardsFlipped = 0;
//variable that will record how many times the user clicks
var numClicks = 0;
//used as an indexes to see if turned cards match
var first;
var second;
//used for 2 cards that don't match to turn them back over
var flippedCard1 = 0;
var flippedCard2 = 0;

//used for number of matches made
var matchesMade = 0;
    
//Main function when user clicks on a card
function flipCard(no){
    var object = document.getElementById("card" + no);
    
    numClicks++;
    document.getElementById("clicks").innerHTML = "Number of Clicks: " + numClicks;
    
    if (cardsFlipped == 2){
        check();
        return;
    }
    
    if(cardsFlipped == 0){
        
        if (no == 1 || no == 9){
            object.src = fruitsArray[0].image;
            first = 0;
        }
        if(no == 2 || no == 8){
            object.src = fruitsArray[4].image;
            first = 4;
        }
        if(no == 3 || no == 7){
            object.src = fruitsArray[1].image;
            first = 1;
        }
        if(no == 4 || no == 5){
            object.src = fruitsArray[3].image;
            first = 3;
        }
        if(no == 6 || no == 10){
            object.src = fruitsArray[2].image;
            first = 2;
        }
        cardsFlipped = 1;
        flippedCard1 = no;
    }
    
    else {
        if (no == 1 || no == 9){
            object.src = fruitsArray[0].image;
            second = 0;
        }
        if(no == 2 || no == 8){
            object.src = fruitsArray[4].image;
            second = 4;
        }
        if(no == 3 || no == 7){
            object.src = fruitsArray[1].image;
            second = 1;
        }
        if(no == 4 || no == 5){
            object.src = fruitsArray[3].image;
            second = 3;
        }
        if(no == 6 || no == 10){
            object.src = fruitsArray[2].image;
            second = 2;
        }
        cardsFlipped = 2;
        flippedCard2 = no;
    }
    
}

//Secondary function needed to check if the two flipped cards match or not
function check() {
    if(fruitsArray[first] == fruitsArray[second]) {
        matchesMade++;
        cardsFlipped = 0;
        alert("Good job! You made a match! ");
        if(matchesMade == 5){
            document.getElementById("finalMessage").innerHTML = "Congrats!! You win!!";
            document.getElementById("finalMessage2").innerHTML = "WINNER! WINNER! WINNER!";
        }
    }
    else {
        document.getElementById("card" + flippedCard1).src = "images/redcard.jpg";
        document.getElementById("card" + flippedCard2).src = "images/redcard.jpg";
        alert("Try Again! ");
        cardsFlipped = 0;
    }
}

    


